// Step 4 - Javascript DOM
const computerChoice = document.getElementById('computer-choice');
const playerChoice = document.getElementById('player-choice');
const resultOutput = document.getElementById('result-output');

const possibleChoices = document.querySelectorAll('button');
let player = '';
let computer = '';
let result = '';

// Step 5 - EventListener
possibleChoices.forEach(choice => {
    choice.addEventListener('click', (e) => {
        player = e.target.id;
        playerChoice.innerHTML = player;
        generateComputerChoice();
        getResult();
    });
});

// Step 6 - generateComputerChoice()
function generateComputerChoice() {
    const randomNum = Math.floor(Math.random() * 3) + 1;

    if (randomNum === 1) {
        computer = 'rock';
    } else if (randomNum === 2) {
        computer = 'paper';
    } else {
        computer = 'scissors';
    }

    computerChoice.innerHTML = `Keuze computer: ${computer}`;
}

// Step 7 - getResult()
function getResult() {
    if (computer === player) {
        result = 'Gelijkspel';
    } else if ((computer === 'rock' && player === 'paper') ||
               (computer === 'paper' && player === 'scissors') ||
               (computer === 'scissors' && player === 'rock')) {
        result = 'Je hebt gewonnen!';
    } else {
        result = 'Je hebt verloren!';
    }

    resultOutput.innerHTML = result;
}



