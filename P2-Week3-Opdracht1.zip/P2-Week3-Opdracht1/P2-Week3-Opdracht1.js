
var winkelmandje = ["Playstation", "Xbox", "PC"];


function updateWinkelmandje() {
  
    var productCount = winkelmandje.length;


    var productCountTekst = "Er zitten " + productCount + " producten in uw winkelmandje";
    var productCountParagraaf = document.createElement("p");
    productCountParagraaf.innerText = productCountTekst;

  
    document.body.appendChild(productCountParagraaf);

   
    var uwProductenParagraaf = document.createElement("p");
    uwProductenParagraaf.innerText = "Uw producten:";
    uwProductenParagraaf.classList.add("bold"); 
    document.body.appendChild(uwProductenParagraaf);

    
    for (var i = 0; i < winkelmandje.length; i++) {
        
        var productParagraaf = document.createElement("p");
        productParagraaf.innerText = winkelmandje[i];
        document.body.appendChild(productParagraaf);
    }
}


updateWinkelmandje();

