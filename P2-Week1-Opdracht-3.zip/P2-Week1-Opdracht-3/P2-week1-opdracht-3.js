function logProductValue() {
    
    var productValue = document.getElementById("productInput").value;

    console.log("Ingevulde product: " + productValue);
}
