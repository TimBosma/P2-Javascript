document.addEventListener("DOMContentLoaded", function() {
 
    let body = document.body;

   
    for (let i = 0; i < 100; i++) {
        let tekst = "Dit is dezelfde tekst, herhaald " + (i + 1) + " keer. ";

        
        let div = document.createElement("div");
        div.textContent = tekst;

        
        body.appendChild(div);
    }
});
