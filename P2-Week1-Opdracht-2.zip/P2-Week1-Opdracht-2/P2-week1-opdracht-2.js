var winkelmandje = ["Bananen", "Bier", "Chips", "Bonen", "Aardappelen"];

function addProduct() {
    var nieuwProduct = prompt("Voer het nieuwe product in:");
    
   
    if (nieuwProduct !== null && nieuwProduct.trim() !== "") {
        
        winkelmandje.push(nieuwProduct);

       
        updateWinkelmandje();
    }
}

function updateWinkelmandje() {
    
    var oudeWinkelmandTekst = "Oude winkelmand: " + winkelmandje.join(", ");
    var oudeWinkelmandParagraaf = document.createElement("p");
    oudeWinkelmandParagraaf.innerText = oudeWinkelmandTekst;

   
    var oudeProductenParagraaf = document.getElementById("productenParagraaf");
    if (oudeProductenParagraaf) {
        document.body.removeChild(oudeProductenParagraaf);
    }

    
    oudeWinkelmandParagraaf.id = "productenParagraaf";
    document.body.appendChild(oudeWinkelmandParagraaf);

    
    winkelmandje.sort();

    
    var gesorteerdeWinkelmandTekst = "Gesorteerde winkelmand: " + winkelmandje.join(", ");
    var gesorteerdeWinkelmandParagraaf = document.createElement("p");
    gesorteerdeWinkelmandParagraaf.innerText = gesorteerdeWinkelmandTekst;

    
    document.body.appendChild(gesorteerdeWinkelmandParagraaf);
}

updateWinkelmandje();