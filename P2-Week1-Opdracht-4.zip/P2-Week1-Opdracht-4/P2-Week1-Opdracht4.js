document.addEventListener("DOMContentLoaded", function () {
    const movingDiv = document.querySelector('.moving-div');
    let currentPosition = 0;

    function moveRight() {
        currentPosition += 1;
        movingDiv.style.left = currentPosition + 'px';

        if (currentPosition < window.innerWidth - 50) {
            requestAnimationFrame(moveRight);
        }
    }

    moveRight();
});
