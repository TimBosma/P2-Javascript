
function displayMultiplicationTable(number) {
    document.write(`<h2>Tafel van ${number}</h2>`);

    
    for (let multiplier = 1; multiplier <= 10; multiplier++) {
        
        const result = number * multiplier;
        document.write(`${multiplier} x ${number} = ${result}<br>`);
    }
}


const desiredNumber = prompt("Enter a number for the multiplication table:");
displayMultiplicationTable(parseInt(desiredNumber));
