let startTime, endTime;

document.getElementById('go-button').addEventListener('click', startGame);
document.getElementById('game-screen').addEventListener('click', endGame);

function startGame() {
  document.getElementById('go-button').style.display = 'none';
  document.getElementById('game-screen').style.backgroundColor = 'red';
  document.getElementById('game-screen').style.display = 'block';

  setTimeout(function () {
    document.getElementById('game-screen').style.backgroundColor = 'green';
    startTime = new Date();
  }, Math.floor(Math.random() * 10000) + 1);
}

function endGame() {
  if (document.getElementById('game-screen').style.backgroundColor === 'green') {
    endTime = new Date();
    const reactionTime = endTime - startTime;
    document.getElementById('result').innerHTML = `Je reactietijd is ${reactionTime} milliseconden`;

    document.getElementById('go-button').style.display = 'block';
    document.getElementById('game-screen').style.display = 'none';

    updateTop5(reactionTime);
    displayTop5();
  }
}

function updateTop5(reactionTime) {
  let top5 = JSON.parse(localStorage.getItem('top5')) || [];

  if (top5.length < 5 || reactionTime < top5[top5.length - 1]) {
    top5.push(reactionTime);
    top5.sort((a, b) => a - b);
    top5 = top5.slice(0, 5);
    localStorage.setItem('top5', JSON.stringify(top5));
  }
}

function displayTop5() {
  const top5 = JSON.parse(localStorage.getItem('top5')) || [];
  const resultDiv = document.getElementById('result');
  resultDiv.innerHTML += '<br><strong>Top 5 Snelste Tijden:</strong>';
  
  if (top5.length > 0) {
    for (let i = 0; i < top5.length; i++) {
      resultDiv.innerHTML += `<br>${i + 1}. ${top5[i]} ms`;
    }
  } else {
    resultDiv.innerHTML += '<br>Nog geen opgeslagen tijden.';
  }
}
