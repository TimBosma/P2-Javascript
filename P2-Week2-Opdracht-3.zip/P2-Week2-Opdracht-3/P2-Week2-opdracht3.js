document.addEventListener("DOMContentLoaded", function () {
    const movingDiv = document.querySelector('.moving-div');
    let currentPosition = 0;
    let moveRight = true;

    function move() {
        if (moveRight) {
            currentPosition += 1;
        } else {
            currentPosition -= 1;
        }

        movingDiv.style.left = currentPosition + 'px';

        if (currentPosition >= window.innerWidth - 50) {
            moveRight = false;
        } else if (currentPosition <= 0) {
            moveRight = true;
        }

        requestAnimationFrame(move);
    }

    // Start the animation
    move();
});
